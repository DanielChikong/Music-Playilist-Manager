package com.example.musicplaylistmanager

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DetailedViewActivity : AppCompatActivity() {

    private lateinit var songs: ArrayList<String>
    private lateinit var artists: ArrayList<String>
    private lateinit var ratings: ArrayList<Int>
    private lateinit var comments: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_view)

        val txtOutput = findViewById<TextView>(R.id.txtOutput)
        val btnDisplay = findViewById<Button>(R.id.btnDisplay)
        val btnAverage = findViewById<Button>(R.id.btnAverage)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // Receive arrays from MainActivity
        songs = intent.getStringArrayListExtra("songs") ?: arrayListOf()
        artists = intent.getStringArrayListExtra("artists") ?: arrayListOf()
        ratings = intent.getIntegerArrayListExtra("ratings") ?: arrayListOf()
        comments = intent.getStringArrayListExtra("comments") ?: arrayListOf()

        // Display all song entries
        btnDisplay.setOnClickListener {
            val builder = StringBuilder()
            if (songs.isEmpty()) {
                builder.append("No songs available.\n")
            } else {
                for (i in songs.indices) {
                    builder.append("🎵 Song: ${songs[i]}\n")
                    builder.append("🎤 Artist: ${artists[i]}\n")
                    builder.append("⭐ Rating: ${ratings[i]}\n")
                    builder.append("💬 Comment: ${comments[i]}\n\n")
                }
            }
            txtOutput.text = builder.toString()
        }

        // Calculate average rating using loop
        btnAverage.setOnClickListener {
            if (ratings.isEmpty()) {
                txtOutput.text = "No ratings to calculate average."
            } else {
                var total = 0
                for (rating in ratings) {
                    total += rating
                }
                val average = total.toDouble() / ratings.size
                txtOutput.text = "⭐ Average Rating: %.2f".format(average)
            }
        }

        // Go back to Main screen
        btnBack.setOnClickListener {
            finish()
        }
    }
}
